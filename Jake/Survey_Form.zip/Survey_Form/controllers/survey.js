module.exports = {
    index_func: function(req, res){
        res.render('index');
    },
}